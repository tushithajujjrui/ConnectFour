import Foundation

fileprivate struct Constants {
    static var winLength = 4
    static var noPiece = 0
    static var xPiece = 1
    static var oPiece = 2
    static var rows = 6
    static var columns = 7
}

fileprivate extension Int {
    static var randomColumn: Int {
        return Int(arc4random_uniform(UInt32(Constants.columns)))
    }
    
    var pieceString: String {
        switch self {
        case Constants.noPiece: return "-"
        case Constants.xPiece: return "X"
        case Constants.oPiece: return "O"
        default: return ""
        }
    }
}

class ConnectFour {
    
    var board = [[Int]]()
    var boardFull: Bool {
        for column in 0..<Constants.columns {
            if board[column][0] == Constants.noPiece {
                return false
            }
        }
        return true
    }
    
    init() {
        clearBoard()
    }
    
    /// Starts a game where pieces are placed randomly
    func startGame(printEachMove: Bool = true, printWinningBoard: Bool = true) {
        clearBoard()
        if printEachMove {
            printBoard()
        }
        var player = Constants.oPiece
        while boardFull == false {
            if placeRandom(player: player) == false {
                if printWinningBoard {
                    printBoard()
                }
                return
            }
            player = (player == Constants.oPiece ? Constants.xPiece : Constants.oPiece)
            if printEachMove {
                printBoard()
            }
        }
    }
    
    func clearBoard() {
        board = [[Int]]()
        for columns in 0..<Constants.columns {
            board.append([Int]())
            for _ in 0..<Constants.rows {
                board[columns].append(Constants.noPiece)
            }
        }
    }
    
    /// Places a Piece on the baord
    ///
    /// - parameter player: Player to place piece for
    /// - parameter column: Column to place piece
    ///
    /// - returns: If the place was able to be placed and if the piece resulted in a win
    func placePiece(player: Int, column: Int) -> (wasPlaced: Bool, winner: Bool) {
        if board[column][0] == Constants.noPiece {
            for row in (0..<Constants.rows).reversed() {
                if board[column][row] == Constants.noPiece {
                    board[column][row] = player
                    if checkWinner(player: player, column: column, row: row) {
                        return (wasPlaced: true, winner: true)
                    }
                    return (wasPlaced: true, winner: false)
                }
            }
        }
        return (wasPlaced: false, winner: false)
    }
    
    /// Places a random piece on the board
    ///
    /// - parameter player: Player to place piece for
    ///
    /// - returns: If piece could be placed. False if board is full or
    func placeRandom(player: Int) -> Bool {
        if boardFull {
            return false
        }
        while (true) {
            let result = placePiece(player: player, column: Int.randomColumn)
            if result.winner {
                return false
            } else if result.wasPlaced {
                return true
            }
        }
    }
    
    /// Checks if the piece played resuled in a win
    ///
    /// - parameter player: Player that played the piece
    /// - parameter column: Column for the piece last placed
    /// - parameter row:    Row for the piece last placed
    ///
    /// - returns: If the piece was a win
    func checkWinner(player: Int, column: Int, row: Int) -> Bool {
        func checkRange(stepColumn: Int, stepRow: Int, steps: Int) -> Int {
            if steps == 0 {
                return 0
            }
            var column2 = column + stepColumn
            var row2 = row + stepRow
            for count in 0..<steps {
                if board[column2][row2] != player {
                    return count
                }
                column2 += stepColumn
                row2 += stepRow
            }
            return steps
        }
        
        let minColumn = max(0, column - (Constants.winLength - 1))
        let maxColumn = min(Constants.columns - 1, column + (Constants.winLength - 1))
        let minRow = max(0, row - (Constants.winLength - 1))
        let maxRow = min(Constants.rows - 1, row + (Constants.winLength - 1))
        
        // Check for wins in all 8 directions
        
        let left = checkRange(stepColumn: -1, stepRow: 0, steps: column - minColumn)
        guard left + 1 < Constants.winLength else {
            print("Horizontal Win")
            return true
        }
        let right = checkRange(stepColumn: 1, stepRow: 0, steps: maxColumn - column)
        guard left + right + 1 < Constants.winLength else {
            print("Horizontal Win")
            return true
        }
        let up = checkRange(stepColumn: 0, stepRow: -1, steps: row - minRow)
        guard up + 1 < Constants.winLength else {
            print("Vertical Win")
            return true
        }
        let down = checkRange(stepColumn: 0, stepRow: 1, steps: maxRow - row)
        guard up + down + 1 < Constants.winLength else {
            print("Vertical Win")
            return true
        }
        let upLeft = checkRange(stepColumn: -1, stepRow: -1, steps: min(row - minRow, column - minColumn))
        guard upLeft + 1 < Constants.winLength else {
            print("Diagonal Down Win")
            return true
        }
        let downRight = checkRange(stepColumn: 1, stepRow: 1, steps: min(maxRow - row, maxColumn - column))
        guard upLeft + downRight + 1 < Constants.winLength else {
            print("Diagonal Down Win")
            return true
        }
        let upRight = checkRange(stepColumn: 1, stepRow: -1, steps: min(row - minRow, maxColumn - column))
        guard upRight + 1 < Constants.winLength else {
            print("Diagonal Up Win")
            return true
        }
        let downLeft = checkRange(stepColumn: -1, stepRow: 1, steps: min(maxRow - row, column - minColumn))
        guard upRight + downLeft + 1 < Constants.winLength else {
            print("Diagonal Up Win")
            return true
        }
        
        return false
    }
    
    func printBoard() {
        for row in 0..<Constants.rows {
            for column in 0..<Constants.columns {
                print("\(board[column][row].pieceString)  ", terminator: "")
            }
            print()
        }
        print()
    }
}


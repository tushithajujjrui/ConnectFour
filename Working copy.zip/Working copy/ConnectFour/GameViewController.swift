//
//  GameViewController.swift
//  ConnectFour
//
//  Created by Koeppen, Stephen C on 4/11/18.
//  Copyright © 2018 Koeppen, Stephen C. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController {
    @IBOutlet weak var mygrid: UIImageView!
    var player = 0
    @IBAction func button1Pressed(_ sender: Any) {
        if(player == 0)
        {
            (sender as AnyObject).setTitle("P1", for: [])
            (sender as AnyObject).setImage(#imageLiteral(resourceName: "red chip"), for: [])
            //(sender as AnyObject).setTitleColor(UIColor.red, for: [])
            player = 1
        }
        else if(player == 1)
        {
            (sender as AnyObject).setTitle("P2", for: [])
            //(sender as AnyObject).setTitleColor(UIColor.yellow, for: [])
            (sender as AnyObject).setImage(#imageLiteral(resourceName: "yellow chip"), for: [])
            player = 0
        }
    }
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let view = self.view as! SKView? {
            // Load the SKScene from 'GameScene.sks'
            if let scene = SKScene(fileNamed: "GameScene") {
                // Set the scale mode to scale to fit the window
                scene.scaleMode = .aspectFill
                
                // Present the scene
                view.presentScene(scene)
            }
            
            view.ignoresSiblingOrder = true
            
            view.showsFPS = true
            view.showsNodeCount = true
        }
    }

    override var shouldAutorotate: Bool {
        return true
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
}

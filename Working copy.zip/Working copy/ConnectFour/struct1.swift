//
//  struct1.swift
//  TicTacToeFinal
//
//  Created by Jujjuri, Tushitha on 10/26/17.
//  Copyright © 2017 Jujjuri, Tushitha. All rights reserved.
//

import Foundation
import UIKit
struct struct1
{
    var button = UIButton()
    var ownedBy = 0
    
    
    
}
